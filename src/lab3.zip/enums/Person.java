package enums;

public enum Person {
    MALE ("л "),
    FEMALE ("ла "),
    NEUTER ("ло "),
    PLURAL ("ли "),
    INFINITIVE ("ть ");
    private final String suffix;

    Person(String suffix) {
        this.suffix = suffix;
    }

    @Override
    public String toString() { return suffix; }

}
