package enums;

public enum HouseSize {
    BIG ("домище"),
    MEDIUM ("дом"),
    SMALL ("домик");
    private final String size;

    HouseSize(String size) {
        this.size = size;
    }

    @Override
    public String toString() { return size; }

}
