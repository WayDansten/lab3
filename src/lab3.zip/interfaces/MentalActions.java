package interfaces;

import enums.Person;
import enums.Truth;

public interface MentalActions {
    public void decide(String decision, Truth t, Person p);
    public void understand(String thought, Truth t, Person p);
    public void know(String knownInformation, Truth t, Person p);
    public void want(String wish, Truth t, Person p);
}
