package interfaces;

import enums.Person;
import enums.Truth;
import objects.Human;

public interface VoiceActions {
    public void say(String message, Human h, Truth t, Person p);
    public void say(String message, Truth t, Person p);
}
