package interfaces;

import enums.Person;
import enums.Truth;

public interface PhysicalActions {
    public void climb(Object o, Truth t, Person p);
    public void climb(Truth t, Person p);
    public void go(Truth t, Person p);
}
