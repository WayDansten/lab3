package interfaces;

import objects.Paper;

public interface MediaActions {
    public void printout();
    public void publish();
    public void read();
}
