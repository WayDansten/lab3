package interfaces;

public interface GeneralActions {
    public void exist();
}
