import enums.HouseSize;
import enums.Person;
import enums.Truth;
import objects.*;

public class lab3 {
    public static void main(String[] args) {
        Human mother = new Human("Мама", false);
        Human father = new Human("Папа", true);
        Human carlson = new Human("Карлсон", true);
        Human bosse = new Human("Боссе", true);
        Human betan = new Human("Бетан", true);
        Human small = new Human("Малыш", true);
        House carsonHouse = new House(1, HouseSize.SMALL);
        mother.decide("", Truth.TRUE, Person.FEMALE);
        father.decide("не говорить, что", Truth.TRUE, Person.MALE);
        carlson.exist();

    }
}