package objects;

import interfaces.GeneralActions;
import interfaces.MentalActions;
import interfaces.PhysicalActions;
import interfaces.VoiceActions;
import enums.*;

public class Human implements VoiceActions, PhysicalActions, MentalActions, GeneralActions {
    private String name;
    private final int dna;
    private final boolean isMale;

    public Human(String name, int dna, boolean isMale) {
        this.name = name;
        this.dna = dna;
        this.isMale = isMale;
    }

    public Human (String name, boolean isMale) {
        this.name = name;
        this.isMale = isMale;
        this.dna = (int) (Math.random() * Math.pow(10, 8));
    }

    @Override
    public void say(String message, Human h, Truth t, Person p) {System.out.print(this + (t + "говори" + p) + h + message);}
    @Override
    public void say(String message, Truth t, Person p) {System.out.print(this + (t + "говори" + p) + message);}

    @Override
    public void climb(Object o, Truth t, Person p) {
        if (p == Person.MALE) {System.out.print(this + (t + "залез на ") + o);}
        else {System.out.print(this + (t + "залез" + p + "на ") + o);}
    }
    @Override
    public void climb(Truth t, Person p) {
        if (p == Person.MALE) {System.out.print(this + (t + "залез "));}
        else {System.out.print(this + (t + "залез" + p));}
    }

    @Override
    public void go(Truth t, Person p) {
        switch(p) {
            case MALE -> System.out.print(this + (t + "пошёл "));
            case INFINITIVE -> System.out.print(this + (t + "пойти "));
            default -> System.out.print(this + (t + "пош" + p));
        }
    }

    @Override
    public void decide(String decision, Truth t, Person p) {System.out.print(this + (t + "реши" + p) + decision);}

    @Override
    public void understand(String thought, Truth t, Person p) {System.out.print(this + (t + "понима" + p) + thought);}

    @Override
    public void know(String knownInformation, Truth t, Person p) {System.out.print(this + (t + "зна" + p) + knownInformation);}

    @Override
    public void want(String wish, Truth t, Person p) {System.out.print(this + (t + "хоте" + p) + wish);}

    @Override
    public void exist() {System.out.print(this + "существует");}

    @Override
    public String toString() { return name; }

    @Override
    public int hashCode() {return dna * name.hashCode();}

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (this.getClass() != obj.getClass()) return false;
        Human human = (Human) obj;
        return dna == human.dna && name.equals(human.name) && isMale == human.isMale;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
