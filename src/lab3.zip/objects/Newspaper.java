package objects;

import interfaces.MediaActions;

import java.util.Objects;

public class Newspaper extends MediaPaper {

    public Newspaper(String title, String content) {
        super(title, content);
    }

    @Override
    public String toString() {return "Газета";}

    @Override
    public int hashCode() {return getTitle().hashCode() * getContent().hashCode();}

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (this.getClass() != obj.getClass()) return false;
        Newspaper n = (Newspaper) obj;
        return getTitle().equals(n.getTitle()) && getContent().equals(n.getContent());
    }

}
