package objects;

import enums.HouseSize;

public class House {
    private int capacity;
    private HouseSize houseSize;

    public House(int capacity, HouseSize houseSize) {
        this.capacity = capacity;
        this.houseSize = houseSize;
    }

    @Override
    public String toString() {return houseSize + "";}

}
