package objects;

import interfaces.MediaActions;

public abstract class MediaPaper extends Paper implements MediaActions {

    private String title;

    public MediaPaper(String title, String content) {
        super(content);
        this.title = title;
    }

    @Override
    public void printout() {
        System.out.println("Напечатан(а) " + this + " под заголовком '" + this.title + "'");
    }

    @Override
    public void publish() {
        System.out.println("Опубликован(а) " + this + " под заголовком '" + this.title + "'");
    }

    @Override
    public void read() {System.out.println("На " + this + " написано: " + super.getContent());}

    public String getTitle() {return title;}

    public void setTitle(String title) {
        this.title = title;
    }

}
