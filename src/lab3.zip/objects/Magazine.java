package objects;

import interfaces.MediaActions;

public class Magazine extends MediaPaper {
    private int pageCount;
    public Magazine(String title, int pageCount, String content) {
        super(title, content);
        this.pageCount = pageCount;
    }

    @Override
    public String toString() {return "Журнал";}

    @Override
    public int hashCode() {return getTitle().hashCode() * getContent().hashCode() * pageCount;}

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (this.getClass() != obj.getClass()) return false;
        Magazine mag = (Magazine) obj;
        return getTitle().equals(mag.getTitle()) && getContent().equals(mag.getContent()) && pageCount == mag.pageCount;
    }

}
